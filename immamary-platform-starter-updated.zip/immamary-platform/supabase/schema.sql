-- IMMAMARY starter schema. Review with a Supabase developer before production.
create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text,
  role text not null default 'public' check (role in ('super_admin','education_manager','venture_manager','missions_manager','public')),
  created_at timestamptz not null default now()
);

create table if not exists public.contact_messages (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  email text not null,
  subject text not null,
  message text not null,
  created_at timestamptz not null default now()
);

create table if not exists public.education_enquiries (
  id uuid primary key default gen_random_uuid(),
  arm text not null default 'education',
  name text not null,
  email text not null,
  phone text,
  message text not null,
  created_at timestamptz not null default now()
);

create table if not exists public.venture_enquiries (
  id uuid primary key default gen_random_uuid(),
  arm text not null default 'venture',
  name text not null,
  email text not null,
  phone text,
  message text not null,
  created_at timestamptz not null default now()
);

create table if not exists public.missions_enquiries (
  id uuid primary key default gen_random_uuid(),
  arm text not null default 'missions',
  name text not null,
  email text not null,
  phone text,
  message text not null,
  created_at timestamptz not null default now()
);

-- Enable RLS. Public users may submit enquiries, but cannot read submissions.
alter table public.profiles enable row level security;
alter table public.contact_messages enable row level security;
alter table public.education_enquiries enable row level security;
alter table public.venture_enquiries enable row level security;
alter table public.missions_enquiries enable row level security;

create policy "Users can read own profile" on public.profiles
  for select to authenticated using (id = auth.uid());

create policy "Public can submit contact messages" on public.contact_messages
  for insert to anon, authenticated with check (true);
create policy "Public can submit education enquiries" on public.education_enquiries
  for insert to anon, authenticated with check (arm = 'education');
create policy "Public can submit venture enquiries" on public.venture_enquiries
  for insert to anon, authenticated with check (arm = 'venture');
create policy "Public can submit missions enquiries" on public.missions_enquiries
  for insert to anon, authenticated with check (arm = 'missions');

-- IMPORTANT: This starter schema intentionally does not grant manager read/update policies.
-- Add tested RLS policies using profiles.role before enabling the production dashboard.
-- Consider a SECURITY DEFINER helper function for role lookup to avoid recursive RLS.
